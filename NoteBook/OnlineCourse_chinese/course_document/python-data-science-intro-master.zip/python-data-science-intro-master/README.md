# python-data-science

This is the git repo for my udemy course: **Python3 for Data Science** https://www.udemy.com/python-for-data-science/?couponCode=PYTHON-DATA-SCI10
